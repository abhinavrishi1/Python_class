#For those that want just a little help, here is the pseudo ReadMe from my answer file.
#-- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

#-- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

class StartFile(object): #This is the main Class that contains all functions

    # creating the readfile function
    
    def ReadFile():
        # When the program starts, load the any data you have
        # in a text file called ToDo.txt into a python Dictionary.
        objFile = open(objFileName, "r")
        for line in objFile:
            strData = line.split(",")  # readline() reads a line of the data into 2 elements
            dicRow = {"Task": strData[0].strip(), "Priority": strData[1].strip()}
            lstTable.append(dicRow)
        objFile.close()
        return lstTable # this exits the ReadFile function and records the lstTable Values

    # Showing users the options to select
    def Options():
        # Display a menu of choices to the user

        print ("""
        Menu of Options
        1) Show current data
        2) Add a new item.
        3) Remove an existing item.
        4) Save Data to File
        5) Exit Program
        """)
        strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
        print()#adding a new line
        return strChoice 


    # Showing the currentList
    def CurrentList(lstTable): #function inside lstTable
    # Display all todo items to user

        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")

    # Adding a task to lstTable values
    def AddTask(lstTable): #adding a task in the lstTable
        # Add a new item to the list/Table

        strTask = str(input("What is the task? - ")).strip()
        strPriority = str(input("What is the priority? [high|low] - ")).strip()
        dicRow = {"Task":strTask,"Priority":strPriority}
        lstTable.append(dicRow)
        StartFile.CurrentList(lstTable)
        return lstTable #new appended lstTable

    # removing the tasks
    def RemoveTask(lstTable):
        # Remove rows in lstTable

        
        StartFile.CurrentList(lstTable)#brings the current list by executing CurrentList function
        strKeyToRemove = input("Which TASK would you like removed? - ")
        blnItemRemoved = False  # Creating a boolean Flag
        intRowNumber = 0
        while (intRowNumber < len(lstTable)):
            if (strKeyToRemove == str(
                    list(dict(lstTable[intRowNumber]).values())[0])):  # the values function creates a list!
                del lstTable[intRowNumber]
                blnItemRemoved = True
            # end if
            intRowNumber += 1
        # end for loop
        # 5b-Update user on the status
        if (blnItemRemoved == True):
            print("The task was removed.")
        else:
            print("I'm sorry, but I could not find that task.")
        # 5c Show the current items in the table
        StartFile.CurrentList(lstTable)
        return lstTable #new saved lstTable values


    # saving items to Todo text file
    def SaveFile(lstData):
        # Save tasks to the ToDo.txt file

        # 6a Show the current items in the table
        StartFile.CurrentList(lstTable)
        # 6b Ask if they want save that data
        if ("y" == str(input("Save this data to file? (y/n) - ")).strip().lower()):
            objFile = open(objFileName, "w")
            for dicRow in lstTable:
                objFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
            objFile.close()
            input("Data saved to file! Press the [Enter] key to return to menu.")
        else:
            input("New data was NOT Saved, but previous data still exists! Press the [Enter] key to return to menu.")


    # exiting the pogram 
    def Exit():
        # Exit program
        exit()

    # Defind the main function under StartFile class
    def MainCode():
        lstTable = StartFile.ReadFile() #step to add values to lstTable
        while (True):
            strChoice = StartFile.Options()
            if(strChoice.strip() == '1'):
                StartFile.CurrentList(lstTable)#if option 1 is selected start CurrentList function and so on
            elif(strChoice.strip() == '2'):
                lstTable = StartFile.AddTask(lstTable)
            elif(strChoice.strip() == '3'):
                lstTable = StartFile.RemoveTask(lstTable)
            elif(strChoice.strip() == '4'):
                StartFile.SaveFile(lstTable)
            elif(strChoice.strip() == '5'):
                StartFile.Exit()

# --- Assign Data Variables

objFileName = "C://Users//abhin//Documents//Python//Module06//Module06//Todo.txt"
strData = ""
dicRow = {}
lstTable = []


# --- Start the program
StartFile.MainCode()
